package com.lordspoker.room;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;

import java.util.*;

public class GameView extends View {
    enum Screen { MENU, POKER, BLACKJACK }
    private Screen screen = Screen.MENU;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rng = new Random();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final SharedPreferences prefs;
    private final ToneGenerator tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 85);
    private boolean soundOn = true;
    private int chips;
    private float den;

    private static final int GREEN_DARK = Color.rgb(2,25,18);
    private static final int GREEN = Color.rgb(4,91,57);
    private static final int GREEN_LIGHT = Color.rgb(8,121,76);
    private static final int GOLD = Color.rgb(217,168,50);
    private static final int GOLD_LIGHT = Color.rgb(247,213,122);
    private static final int PANEL = Color.argb(235,3,22,17);
    private static final int WHITE = Color.rgb(247,246,238);
    private static final int MUTED = Color.rgb(174,188,181);
    private static final int RED = Color.rgb(174,50,45);

    static class OpponentDef {
        final String name; final int res;
        OpponentDef(String n,int r){name=n;res=r;}
    }
    private final OpponentDef[] roster = new OpponentDef[]{
        new OpponentDef("Lord Epstein", R.drawable.npc_lord_epstein),
        new OpponentDef("Greatest president", R.drawable.npc_greatest_president),
        new OpponentDef("Mr H.", R.drawable.npc_mr_h),
        new OpponentDef("Движухамэн", R.drawable.npc_dvizhuhamen),
        new OpponentDef("King of jews", R.drawable.npc_king_of_jews),
        new OpponentDef("Vinny Puh", R.drawable.npc_vinny_puh),
        new OpponentDef("No name", R.drawable.npc_no_name),
        new OpponentDef("Мистер Позитивный", R.drawable.npc_mister_pozitivniy),
        new OpponentDef("Вкусненький малышочек", R.drawable.npc_vkusnenkiy_malish),
        new OpponentDef("Riona", R.drawable.npc_riona),
        new OpponentDef("Maya suchka", R.drawable.npc_maya_suchka),
        new OpponentDef("Не лузающий", R.drawable.npc_ne_luzayushiy),
        new OpponentDef("Mr M", R.drawable.npc_mr_m),
        new OpponentDef("KaBoom4ik", R.drawable.npc_kaboom4ik)
    };
    private final HashMap<Integer, Bitmap> avatars = new HashMap<>();

    static class Hit { RectF r; String a; Hit(RectF rr,String aa){r=rr;a=aa;} }
    private final ArrayList<Hit> hits = new ArrayList<>();

    static class Card {
        int r,s; Card(int rr,int ss){r=rr;s=ss;}
        String rank(){return r<=10?String.valueOf(r):r==11?"J":r==12?"Q":r==13?"K":"A";}
        String suit(){return s==0?"♠":s==1?"♥":s==2?"♦":"♣";}
    }
    static class Deck {
        ArrayList<Card> cards=new ArrayList<>(); int i=0;
        Deck(int decks, Random rng){ for(int d=0;d<decks;d++)for(int s=0;s<4;s++)for(int r=2;r<=14;r++)cards.add(new Card(r,s)); Collections.shuffle(cards,rng); }
        Card draw(){ if(i>=cards.size())return null; return cards.get(i++); }
    }
    static class HandValue implements Comparable<HandValue> {
        int[] v; String label; HandValue(int[] vv,String l){v=vv;label=l;}
        @Override public int compareTo(HandValue o){int n=Math.max(v.length,o.v.length);for(int i=0;i<n;i++){int a=i<v.length?v[i]:0,b=i<o.v.length?o.v[i]:0;if(a!=b)return a-b;}return 0;}
    }

    static class Player {
        String name; int avatar; boolean user; int stack=2000; ArrayList<Card> hand=new ArrayList<>();
        boolean folded,allIn,needsAction; int streetBet,totalBet; String action=""; HandValue finalValue;
        Player(String n,int a,boolean u){name=n;avatar=a;user=u;}
    }

    private ArrayList<Player> pp = new ArrayList<>();
    private ArrayList<Card> board = new ArrayList<>();
    private Deck pokerDeck;
    private int dealer=0, actor=-1, stage=0, currentBet=0, minRaise=20, handNo=0, raiseTarget=40;
    private boolean pokerHandOver=false, pokerShowdown=false, pokerBusy=false;
    private String pokerMessage="";
    private final ArrayList<String> showdownLines=new ArrayList<>();

    static class BJHand {
        ArrayList<Card> cards=new ArrayList<>(); int bet; boolean stood,busted,doubled,fromSplit; String result="";
        BJHand(int b){bet=b;}
    }
    private Deck bjDeck;
    private OpponentDef bjDealer;
    private ArrayList<OpponentDef> bjOthers = new ArrayList<>();
    private ArrayList<BJHand> bjHands = new ArrayList<>();
    private ArrayList<Card> dealerCards = new ArrayList<>();
    private ArrayList<ArrayList<Card>> bjOtherHands = new ArrayList<>();
    private int bjHandIndex=0,bjBet=100; private boolean bjRound=false,bjDone=false,dealerReveal=false,insuranceOffered=false,insuranceTaken=false; private int insuranceBet=0;
    private String bjMessage="Сделайте ставку";

    static class Confetti { float x,y,vx,vy,rot,vr; int color; long born,life; }
    static class Firework { float x,y,r,max; int color; long born,life; }
    static class ChipFly { float x0,y0,x1,y1; long born,life; int amount; }
    private final ArrayList<Confetti> confetti=new ArrayList<>();
    private final ArrayList<Firework> fireworks=new ArrayList<>();
    private final ArrayList<ChipFly> chipFlys=new ArrayList<>();

    public GameView(Context c){
        super(c); den=getResources().getDisplayMetrics().density;
        setLayerType(View.LAYER_TYPE_HARDWARE,null);
        prefs=c.getSharedPreferences("lords_poker",Context.MODE_PRIVATE);
        chips=prefs.getInt("chips",5000); soundOn=prefs.getBoolean("sound",true);
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(dp(2));
        for(OpponentDef d:roster)avatars.put(d.res, BitmapFactory.decodeResource(getResources(),d.res));
        setKeepScreenOn(true);
    }
    private float dp(float v){return v*den;}
    private void save(){prefs.edit().putInt("chips",chips).putBoolean("sound",soundOn).apply();}

    @Override protected void onDraw(Canvas c){
        super.onDraw(c); hits.clear();
        drawBackground(c);
        if(screen==Screen.MENU)drawMenu(c); else if(screen==Screen.POKER)drawPoker(c); else drawBlackjack(c);
        drawEffects(c);
    }

    private void drawBackground(Canvas c){
        LinearGradient g=new LinearGradient(0,0,0,getHeight(),Color.rgb(2,25,18),Color.BLACK,Shader.TileMode.CLAMP);
        p.setShader(g); c.drawRect(0,0,getWidth(),getHeight(),p); p.setShader(null);
    }
    private void txt(Canvas c,String s,float x,float y,float size,int color,Paint.Align align,boolean bold){
        p.setColor(color);p.setTextSize(dp(size));p.setTextAlign(align);p.setTypeface(bold?Typeface.create("sans",Typeface.BOLD):Typeface.create("sans",Typeface.NORMAL));
        c.drawText(s,x,y,p);
    }
    private void round(Canvas c,RectF r,float rad,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(r,dp(rad),dp(rad),p);}
    private void outline(Canvas c,RectF r,float rad,int color,float sw){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(sw));p.setColor(color);c.drawRoundRect(r,dp(rad),dp(rad),p);p.setStyle(Paint.Style.FILL);}
    private void button(Canvas c,RectF r,String label,String action,boolean primary){
        round(c,r,12,primary?GOLD:PANEL);outline(c,r,12,primary?GOLD_LIGHT:Color.rgb(50,72,64),1.2f);
        txt(c,label,r.centerX(),r.centerY()+dp(5),primary?14:13,primary?Color.rgb(24,22,13):WHITE,Paint.Align.CENTER,true);hits.add(new Hit(r,action));
    }
    private void topBar(Canvas c){
        float h=Math.min(dp(64),getHeight()*.095f);p.setColor(Color.argb(245,2,25,18));c.drawRect(0,0,getWidth(),h,p);
        txt(c,"♠",dp(22),h*.66f,28,GOLD,Paint.Align.LEFT,true);
        txt(c,"LORDS OF THE POKER ROOM",dp(58),h*.63f,getWidth()<700?12:16,WHITE,Paint.Align.LEFT,true);
        String money="◎ "+chips; txt(c,money,getWidth()-dp(78),h*.63f,16,WHITE,Paint.Align.RIGHT,true);
        RectF snd=new RectF(getWidth()-dp(66),dp(8),getWidth()-dp(12),h-dp(8));round(c,snd,14,Color.argb(180,8,39,29));txt(c,soundOn?"🔊":"🔇",snd.centerX(),snd.centerY()+dp(7),19,WHITE,Paint.Align.CENTER,false);hits.add(new Hit(snd,"sound"));
    }

    private void drawMenu(Canvas c){
        topBar(c); float w=getWidth(),h=getHeight(); boolean land=w>h;
        float y=land?h*.25f:h*.24f;
        txt(c,"LORDS OF THE",w/2,y,land?31:29,WHITE,Paint.Align.CENTER,true);
        txt(c,"POKER ROOM",w/2,y+dp(38),land?31:29,GOLD_LIGHT,Paint.Align.CENTER,true);
        txt(c,"Сразитесь с сильнейшими игроками в карты со всего мира",w/2,y+dp(72),land?11:10,MUTED,Paint.Align.CENTER,false);
        float bw=land?Math.min(dp(300),w*.34f):w*.78f,bh=dp(72),gap=dp(18);float bx=(w-bw)/2,by=y+dp(105);
        RectF b1=new RectF(bx,by,bx+bw,by+bh);button(c,b1,"BADASS HOLDEM","menuPoker",true);
        RectF b2=new RectF(bx,by+bh+gap,bx+bw,by+2*bh+gap);button(c,b2,"BLACKJACKPORTER","menuBJ",false);
        txt(c,"Нативная Android-версия · без браузера и прокрутки",w/2,h-dp(24),9,Color.rgb(116,139,129),Paint.Align.CENTER,false);
    }

    private RectF tableRect(){
        float top=Math.min(dp(66),getHeight()*.1f)+dp(7),margin=dp(8);return new RectF(margin,top,getWidth()-margin,getHeight()-dp(5));
    }
    private void drawTable(Canvas c,RectF t){
        p.setColor(Color.rgb(64,38,23));c.drawRoundRect(t,t.width()*.19f,t.height()*.14f,p);
        RectF g=new RectF(t);g.inset(dp(7),dp(7));p.setColor(GOLD);c.drawRoundRect(g,g.width()*.19f,g.height()*.14f,p);
        RectF felt=new RectF(g);felt.inset(dp(5),dp(5));RadialGradient rg=new RadialGradient(felt.centerX(),felt.centerY(),Math.max(felt.width(),felt.height())*.55f,GREEN_LIGHT,GREEN_DARK,Shader.TileMode.CLAMP);p.setShader(rg);c.drawRoundRect(felt,felt.width()*.19f,felt.height()*.14f,p);p.setShader(null);
        outline(c,new RectF(felt.left+dp(16),felt.top+dp(16),felt.right-dp(16),felt.bottom-dp(16)),felt.width()*.18f,Color.argb(70,220,191,112),1);
        txt(c,"LORDS OF THE POKER ROOM",felt.centerX(),felt.centerY()+dp(8),Math.max(18,Math.min(38,felt.width()/34)),Color.argb(34,255,255,255),Paint.Align.CENTER,true);
    }

    private ArrayList<OpponentDef> randomOpponents(int n){
        ArrayList<OpponentDef> a=new ArrayList<>(Arrays.asList(roster));Collections.shuffle(a,rng);return new ArrayList<>(a.subList(0,Math.min(n,a.size())));
    }
    private void newPokerRoster(){
        pp.clear();pp.add(new Player("Вы",0,true));int n=2+rng.nextInt(4);for(OpponentDef d:randomOpponents(n))pp.add(new Player(d.name,d.res,false));dealer=rng.nextInt(pp.size());handNo=0;startPokerHand();
    }
    private int nextSeat(int from){return (from+1)%pp.size();}
    private int nextLive(int from){int i=from;for(int k=0;k<pp.size();k++){i=nextSeat(i);Player q=pp.get(i);if(!q.folded&&!q.allIn)return i;}return -1;}
    private int nextAnyLive(int from){int i=from;for(int k=0;k<pp.size();k++){i=nextSeat(i);if(!pp.get(i).folded)return i;}return -1;}
    private int activeCount(){int n=0;for(Player q:pp)if(!q.folded)n++;return n;}
    private int actionableCount(){int n=0;for(Player q:pp)if(!q.folded&&!q.allIn)n++;return n;}
    private int pot(){int z=0;for(Player q:pp)z+=q.totalBet;return z;}
    private void startPokerHand(){
        if(pp.isEmpty())return;handNo++;pokerHandOver=false;pokerShowdown=false;pokerBusy=false;showdownLines.clear();board.clear();pokerDeck=new Deck(1,rng);stage=0;currentBet=0;minRaise=20;
        boolean needRoster=false;for(Player q:pp)if(q.stack<=0)needRoster=true;if(needRoster){ for(Player q:pp)q.stack=2000; }
        dealer=nextSeat(dealer);
        for(Player q:pp){q.hand.clear();q.folded=false;q.allIn=false;q.needsAction=false;q.streetBet=0;q.totalBet=0;q.action="";q.finalValue=null;}
        for(int r=0;r<2;r++)for(int k=1;k<=pp.size();k++){int i=(dealer+k)%pp.size();pp.get(i).hand.add(pokerDeck.draw());}
        int sb,bb;if(pp.size()==2){sb=dealer;bb=nextSeat(dealer);}else{sb=nextSeat(dealer);bb=nextSeat(sb);}postBet(sb,10,"SB 10");postBet(bb,20,"BB 20");currentBet=20;minRaise=20;raiseTarget=40;
        for(Player q:pp)if(!q.allIn)q.needsAction=true;
        actor=pp.size()==2?dealer:nextSeat(bb);actor=findNextNeed(actor-1<0?pp.size()-1:actor-1);
        pokerMessage="Раздача #"+handNo+" · Preflop";invalidate();scheduleAI();
    }
    private void postBet(int idx,int amount,String label){Player q=pp.get(idx);int pay=Math.min(q.stack,amount);q.stack-=pay;q.streetBet+=pay;q.totalBet+=pay;if(q.stack==0)q.allIn=true;q.action=label;}
    private int findNextNeed(int from){int i=from;for(int k=0;k<pp.size();k++){i=nextSeat(i);Player q=pp.get(i);if(!q.folded&&!q.allIn&&q.needsAction)return i;}return -1;}
    private void pokerAction(String type){
        if(pokerBusy||pokerHandOver||actor<0||!pp.get(actor).user)return;Player q=pp.get(actor);boolean raised=false;
        if(type.equals("fold")){q.folded=true;q.needsAction=false;q.action="Fold";}
        else if(type.equals("checkcall")){int need=currentBet-q.streetBet;if(need<=0){q.action="Check";}else{int pay=Math.min(q.stack,need);q.stack-=pay;q.streetBet+=pay;q.totalBet+=pay;q.action=pay<need?"All-in "+pay:"Call "+pay;if(q.stack==0)q.allIn=true;}q.needsAction=false;animateBet(actor);}
        else if(type.equals("raise")){int target=Math.max(currentBet+minRaise,raiseTarget);target=Math.min(target,q.streetBet+q.stack);raised=raiseTo(actor,target);}
        else if(type.equals("allin")){int target=q.streetBet+q.stack;raised=raiseTo(actor,target);}
        afterPokerAction(actor,raised);
    }
    private boolean raiseTo(int idx,int target){
        Player q=pp.get(idx);int old=currentBet;int pay=Math.max(0,target-q.streetBet);pay=Math.min(pay,q.stack);q.stack-=pay;q.streetBet+=pay;q.totalBet+=pay;if(q.stack==0)q.allIn=true;
        boolean raised=q.streetBet>old;if(raised){int inc=q.streetBet-old;if(inc>=minRaise)minRaise=inc;currentBet=q.streetBet;for(int i=0;i<pp.size();i++){Player o=pp.get(i);if(i!=idx&&!o.folded&&!o.allIn)o.needsAction=true;}q.action=(q.allIn?"All-in ":"Raise ")+q.streetBet;raiseTarget=Math.min(q.streetBet+q.stack,Math.max(currentBet+minRaise,currentBet*2));} else q.action=q.allIn?"All-in":"Call";q.needsAction=false;animateBet(idx);return raised;
    }
    private void afterPokerAction(int idx,boolean raised){
        pp.get(idx).needsAction=false;if(activeCount()==1){awardLast();return;}
        if(actionableCount()==0){runoutAndShowdown();return;}
        int nx=findNextNeed(idx);if(nx<0){endPokerStreet();return;}actor=nx;raiseTarget=Math.max(currentBet+minRaise,currentBet==0?20:currentBet*2);invalidate();scheduleAI();
    }
    private void endPokerStreet(){
        for(Player q:pp){q.streetBet=0;q.needsAction=false;q.action="";}currentBet=0;minRaise=20;stage++;
        if(stage==1){board.add(pokerDeck.draw());board.add(pokerDeck.draw());board.add(pokerDeck.draw());pokerMessage="Раздача #"+handNo+" · Flop";}
        else if(stage==2){board.add(pokerDeck.draw());pokerMessage="Раздача #"+handNo+" · Turn";}
        else if(stage==3){board.add(pokerDeck.draw());pokerMessage="Раздача #"+handNo+" · River";}
        else{showdownPoker();return;}
        if(actionableCount()<=1){runoutAndShowdown();return;}
        for(Player q:pp)if(!q.folded&&!q.allIn)q.needsAction=true;actor=findNextNeed(dealer);raiseTarget=20;invalidate();scheduleAI();
    }
    private void runoutAndShowdown(){while(board.size()<5)board.add(pokerDeck.draw());stage=4;showdownPoker();}
    private void awardLast(){int win=-1;for(int i=0;i<pp.size();i++)if(!pp.get(i).folded){win=i;break;}int pot=pot();if(win>=0){pp.get(win).stack+=pot;pp.get(win).action="WIN +"+pot;animatePotTo(win);if(pp.get(win).user)celebrate();}pokerMessage="Банк забран без вскрытия";pokerHandOver=true;actor=-1;invalidate();}
    private void showdownPoker(){
        pokerShowdown=true;pokerHandOver=true;actor=-1;showdownLines.clear();for(Player q:pp)if(!q.folded){ArrayList<Card> seven=new ArrayList<>(q.hand);seven.addAll(board);q.finalValue=evaluate(seven);}
        TreeSet<Integer> levels=new TreeSet<>();for(Player q:pp)if(q.totalBet>0)levels.add(q.totalBet);int prev=0;HashMap<Player,Integer> won=new HashMap<>();
        for(int level:levels){int contributors=0;for(Player q:pp)if(q.totalBet>=level)contributors++;int side=(level-prev)*contributors;prev=level;if(side<=0)continue;ArrayList<Player> elig=new ArrayList<>();for(Player q:pp)if(!q.folded&&q.totalBet>=level)elig.add(q);if(elig.isEmpty())continue;HandValue best=null;for(Player q:elig)if(best==null||q.finalValue.compareTo(best)>0)best=q.finalValue;ArrayList<Player> ws=new ArrayList<>();for(Player q:elig)if(q.finalValue.compareTo(best)==0)ws.add(q);int share=side/ws.size(),rem=side%ws.size();for(int i=0;i<ws.size();i++){Player q=ws.get(i);int add=share+(i<rem?1:0);q.stack+=add;won.put(q,won.containsKey(q)?won.get(q)+add:add);}}
        boolean userWon=false;for(Player q:pp){if(q.folded)showdownLines.add(q.name+" — Fold");else{int w=won.containsKey(q)?won.get(q):0;showdownLines.add(q.name+" — "+q.finalValue.label+(w>0?"  +"+w:""));if(q.user&&w>0)userWon=true;}}
        for(Player q:won.keySet())q.action="WIN +"+won.get(q);if(userWon)celebrate();pokerMessage="Вскрытие";invalidate();handler.postDelayed(new Runnable(){public void run(){invalidate();}},1000);
    }
    private void scheduleAI(){
        if(actor<0||pokerHandOver||pp.get(actor).user)return;pokerBusy=true;handler.postDelayed(new Runnable(){public void run(){pokerBusy=false;if(actor<0||pokerHandOver||pp.get(actor).user)return;aiPoker(actor);}},350+rng.nextInt(350));
    }
    private void aiPoker(int idx){
        Player q=pp.get(idx);int need=currentBet-q.streetBet;double strength=aiStrength(q);double pressure=q.stack==0?1:(double)need/Math.max(1,q.stack);double roll=rng.nextDouble();boolean raised=false;
        if(need>0 && strength<0.28 && pressure>0.08 && roll<0.70){q.folded=true;q.action="Fold";q.needsAction=false;}
        else if((strength>0.77&&roll<0.52)||(strength>0.58&&roll<0.18)){int target=Math.min(q.streetBet+q.stack,Math.max(currentBet+minRaise,currentBet==0?20:currentBet*2));raised=raiseTo(idx,target);}
        else{int pay=Math.min(q.stack,need);q.stack-=pay;q.streetBet+=pay;q.totalBet+=pay;if(q.stack==0)q.allIn=true;q.action=need==0?"Check":pay<need?"All-in "+pay:"Call "+pay;q.needsAction=false;if(pay>0)animateBet(idx);}
        afterPokerAction(idx,raised);
    }
    private double aiStrength(Player q){
        if(stage==0){Card a=q.hand.get(0),b=q.hand.get(1);double x=(a.r+b.r)/28.0;if(a.r==b.r)x=.55+a.r/30.0;if(a.s==b.s)x+=.06;if(Math.abs(a.r-b.r)<=2)x+=.04;if(a.r>=13||b.r>=13)x+=.06;return Math.min(1,x);}
        ArrayList<Card> a=new ArrayList<>(q.hand);a.addAll(board);HandValue hv=evaluate(a);return Math.min(1,.18+hv.v[0]*.115+(hv.v.length>1?hv.v[1]/100.0:0));
    }

    private String stageName(){return stage==0?"Preflop":stage==1?"Flop":stage==2?"Turn":stage==3?"River":"Showdown";}
    private HandValue userCurrent(){if(pp.isEmpty())return null;Player u=pp.get(0);if(stage==0){Card a=u.hand.get(0),b=u.hand.get(1);if(a.r==b.r)return new HandValue(new int[]{1,a.r},"Карманная пара · "+a.rank());return new HandValue(new int[]{0,Math.max(a.r,b.r)},a.rank()+a.suit()+"  "+b.rank()+b.suit());}ArrayList<Card>x=new ArrayList<>(u.hand);x.addAll(board);return evaluate(x);}

    private void drawPoker(Canvas c){
        topBar(c);RectF t=tableRect();drawTable(c,t);boolean land=getWidth()>getHeight();
        drawPokerMessage(c,t);drawPokerSeats(c,t,land);drawPokerCenter(c,t,land);drawPokerControls(c,t,land);
        if(pokerHandOver){RectF nb=new RectF(t.centerX()-dp(75),t.bottom-dp(66),t.centerX()+dp(75),t.bottom-dp(16));button(c,nb,"НОВАЯ РАЗДАЧА","newPokerHand",true);}
        RectF back=new RectF(dp(12),dp(72),dp(56),dp(112));round(c,back,10,Color.argb(180,4,30,22));txt(c,"‹",back.centerX(),back.centerY()+dp(8),26,WHITE,Paint.Align.CENTER,true);hits.add(new Hit(back,"back"));
    }
    private void drawPokerMessage(Canvas c,RectF t){
        float mw=Math.min(dp(190),t.width()*.28f),mh=dp(38);RectF m=new RectF(t.left+t.width()*.09f,t.top+t.height()*.18f,t.left+t.width()*.09f+mw,t.top+t.height()*.18f+mh);round(c,m,11,Color.argb(220,3,25,18));outline(c,m,11,Color.rgb(126,104,55),1);txt(c,pokerMessage,m.left+dp(10),m.centerY()+dp(4),9,WHITE,Paint.Align.LEFT,true);
    }
    private PointF seatPos(RectF t,int idx,boolean land){
        if(idx==0)return new PointF(t.centerX(),t.bottom-(land?dp(145):dp(170)));
        int n=pp.size()-1;double a1=Math.toRadians(-160),a2=Math.toRadians(-20);double a=n==1?-Math.PI/2:a1+(a2-a1)*(idx-1)/(double)(n-1);float rx=t.width()*(land?.39f:.37f),ry=t.height()*(land?.34f:.35f);float x=t.centerX()+(float)Math.cos(a)*rx;float y=t.centerY()+(float)Math.sin(a)*ry;float pad=land?dp(92):dp(76);x=Math.max(t.left+pad,Math.min(t.right-pad,x));y=Math.max(t.top+dp(70),Math.min(t.bottom-dp(110),y));return new PointF(x,y);
    }
    private void drawPokerSeats(Canvas c,RectF t,boolean land){for(int i=0;i<pp.size();i++)drawPokerSeat(c,t,i,seatPos(t,i,land),land);}
    private void drawPokerSeat(Canvas c,RectF t,int idx,PointF pos,boolean land){
        Player q=pp.get(idx);float sw=land?dp(170):Math.min(dp(170),getWidth()*.39f),sh=land?dp(92):dp(105);if(q.user){sw=land?dp(190):Math.min(dp(210),getWidth()*.52f);sh=land?dp(100):dp(116);}RectF box=new RectF(pos.x-sw/2,pos.y-sh/2,pos.x+sw/2,pos.y+sh/2);round(c,box,12,q.folded?Color.argb(155,3,20,16):PANEL);if(idx==actor)outline(c,box,12,GOLD,2);
        float av=q.user?(land?dp(62):dp(66)):(land?dp(58):dp(54));RectF ar=new RectF(box.left+dp(7),box.top+(sh-av)/2,box.left+dp(7)+av,box.top+(sh-av)/2+av);if(q.user){round(c,ar,10,Color.rgb(30,70,57));txt(c,"YOU",ar.centerX(),ar.centerY()+dp(7),18,WHITE,Paint.Align.CENTER,true);}else drawAvatar(c,q.avatar,ar,10);outline(c,ar,10,GOLD,1.5f);
        float tx=ar.right+dp(8);txt(c,q.name,tx,box.top+dp(23),q.user?11:10,WHITE,Paint.Align.LEFT,true);txt(c,"◎ "+q.stack,tx,box.top+dp(42),10,GOLD_LIGHT,Paint.Align.LEFT,true);txt(c,q.action,tx,box.top+dp(60),8.5f,MUTED,Paint.Align.LEFT,false);
        if(!q.user){float cy=box.bottom-dp(5);if(pokerShowdown&&!q.folded){drawMiniCard(c,q.hand.get(0),box.centerX()-dp(19),cy,land);drawMiniCard(c,q.hand.get(1),box.centerX()+dp(19),cy,land);if(q.finalValue!=null)txt(c,q.finalValue.label,box.centerX(),box.bottom+dp(15),7.5f,GOLD_LIGHT,Paint.Align.CENTER,true);}else{drawCardBack(c,box.centerX()-dp(19),cy,land);drawCardBack(c,box.centerX()+dp(19),cy,land);}}
        else{float cy=box.bottom+dp(15);drawMiniCard(c,q.hand.get(0),box.centerX()-dp(22),cy,false);drawMiniCard(c,q.hand.get(1),box.centerX()+dp(22),cy,false);}
    }
    private void drawAvatar(Canvas c,int res,RectF r,float rad){Bitmap b=avatars.get(res);if(b==null){round(c,r,rad,Color.DKGRAY);return;}Path path=new Path();path.addRoundRect(r,dp(rad),dp(rad),Path.Direction.CW);c.save();c.clipPath(path);Rect src=coverSrc(b,r);c.drawBitmap(b,src,r,p);c.restore();}
    private Rect coverSrc(Bitmap b,RectF dest){float sr=(float)b.getWidth()/b.getHeight(),dr=dest.width()/dest.height();if(sr>dr){int nw=(int)(b.getHeight()*dr),l=(b.getWidth()-nw)/2;return new Rect(l,0,l+nw,b.getHeight());}int nh=(int)(b.getWidth()/dr),top=(b.getHeight()-nh)/2;return new Rect(0,top,b.getWidth(),top+nh);}
    private void drawPokerCenter(Canvas c,RectF t,boolean land){
        float cy=t.centerY()+(land?dp(12):-dp(5));txt(c,"Банк: ◎ "+pot(),t.centerX(),cy-(land?dp(58):dp(78)),11,GOLD_LIGHT,Paint.Align.CENTER,true);
        float gap=land?dp(48):Math.min(dp(52),t.width()/6f);float start=t.centerX()-gap*2;for(int i=0;i<board.size();i++)drawFullCard(c,board.get(i),start+i*gap,cy,land?0.80f:0.92f);
        HandValue hv=userCurrent();if(hv!=null){RectF cr=new RectF(t.centerX()-dp(115),cy+(land?dp(46):dp(58)),t.centerX()+dp(115),cy+(land?dp(78):dp(92)));round(c,cr,10,Color.argb(220,3,27,20));txt(c,"ВАША КОМБИНАЦИЯ",cr.centerX(),cr.top+dp(11),7,GOLD_LIGHT,Paint.Align.CENTER,true);txt(c,hv.label,cr.centerX(),cr.bottom-dp(8),10,WHITE,Paint.Align.CENTER,true);}
        if(pokerShowdown&&!showdownLines.isEmpty()){float x=t.right-t.width()*.09f,y=t.top+t.height()*.20f;for(String line:showdownLines){txt(c,line,x,y,7.5f,WHITE,Paint.Align.RIGHT,true);y+=dp(14);}}
    }
    private void drawPokerControls(Canvas c,RectF t,boolean land){if(pokerHandOver||actor<0||!pp.get(actor).user)return;Player u=pp.get(actor);float h=land?dp(55):dp(68),w=Math.min(t.width()*.72f,land?dp(700):t.width()*.92f),x=t.centerX()-w/2,y=t.bottom-h-dp(8);RectF panel=new RectF(x,y,x+w,y+h);round(c,panel,16,Color.argb(245,1,18,14));float gap=dp(6),bw=(w-gap*5)/4;float by=y+dp(8),bh=h-dp(16);RectF f=new RectF(x+gap,by,x+gap+bw,by+bh);
        button(c,f,"FOLD","fold",false);
        int need=currentBet-u.streetBet;RectF cc=new RectF(f.right+gap,by,f.right+gap+bw,by+bh);button(c,cc,need<=0?"CHECK":"CALL "+need,"checkcall",false);
        RectF rr=new RectF(cc.right+gap,by,cc.right+gap+bw,by+bh);button(c,rr,(currentBet==0?"BET ":"RAISE ")+raiseTarget,"raise",true);
        RectF aa=new RectF(rr.right+gap,by,rr.right+gap+bw,by+bh);button(c,aa,"ALL-IN "+u.stack,"allin",false);
        if(!land){RectF minus=new RectF(rr.left,rr.top-dp(40),rr.left+dp(40),rr.top-dp(5));RectF plus=new RectF(rr.right-dp(40),rr.top-dp(40),rr.right,rr.top-dp(5));button(c,minus,"−","raiseMinus",false);button(c,plus,"+","raisePlus",false);}
    }

    private void drawMiniCard(Canvas c,Card card,float cx,float bottom,boolean tiny){float w=tiny?dp(31):dp(38),h=tiny?dp(43):dp(52);RectF r=new RectF(cx-w/2,bottom-h,cx+w/2,bottom);round(c,r,6,Color.rgb(247,246,240));int col=(card.s==1||card.s==2)?Color.rgb(199,46,43):Color.rgb(21,26,25);txt(c,card.rank(),r.left+dp(5),r.top+dp(14),9,col,Paint.Align.LEFT,true);txt(c,card.suit(),r.centerX(),r.centerY()+dp(8),tiny?15:18,col,Paint.Align.CENTER,false);}
    private void drawCardBack(Canvas c,float cx,float bottom,boolean tiny){float w=tiny?dp(31):dp(38),h=tiny?dp(43):dp(52);RectF r=new RectF(cx-w/2,bottom-h,cx+w/2,bottom);round(c,r,6,Color.rgb(218,222,218));RectF in=new RectF(r);in.inset(dp(3),dp(3));round(c,in,4,Color.rgb(16,64,82));for(float x=in.left-dp(20);x<in.right+dp(20);x+=dp(9)){p.setColor(Color.argb(90,87,144,163));p.setStrokeWidth(dp(3));c.drawLine(x,in.bottom,x+dp(40),in.top,p);}}
    private void drawFullCard(Canvas c,Card card,float cx,float cy,float scale){float w=dp(48)*scale,h=dp(68)*scale;RectF r=new RectF(cx-w/2,cy-h/2,cx+w/2,cy+h/2);round(c,r,8,Color.rgb(248,247,242));int col=(card.s==1||card.s==2)?Color.rgb(201,48,44):Color.rgb(20,24,23);txt(c,card.rank(),r.left+dp(6),r.top+dp(17),11*scale,col,Paint.Align.LEFT,true);txt(c,card.suit(),r.centerX(),r.centerY()+dp(10),25*scale,col,Paint.Align.CENTER,false);}

    private void animateBet(int idx){RectF t=tableRect();PointF s=seatPos(t,idx,getWidth()>getHeight());ChipFly f=new ChipFly();f.x0=s.x;f.y0=s.y;f.x1=t.centerX();f.y1=t.centerY()-dp(28);f.born=System.currentTimeMillis();f.life=430;chipFlys.add(f);invalidate();}
    private void animatePotTo(int idx){RectF t=tableRect();PointF s=seatPos(t,idx,getWidth()>getHeight());for(int k=0;k<8;k++){ChipFly f=new ChipFly();f.x0=t.centerX()+rng.nextInt(30)-15;f.y0=t.centerY();f.x1=s.x+rng.nextInt(30)-15;f.y1=s.y;f.born=System.currentTimeMillis()+k*35;f.life=520;chipFlys.add(f);}invalidate();}

    // ---------- Hand evaluator ----------
    private HandValue evaluate(List<Card> cards){
        if(cards.size()<5){int hi=0;for(Card c:cards)hi=Math.max(hi,c.r);return new HandValue(new int[]{0,hi},"Старшая карта · "+rankName(hi));}
        HandValue best=null;int n=cards.size();for(int a=0;a<n-4;a++)for(int b=a+1;b<n-3;b++)for(int d=b+1;d<n-2;d++)for(int e=d+1;e<n-1;e++)for(int f=e+1;f<n;f++){Card[] x={cards.get(a),cards.get(b),cards.get(d),cards.get(e),cards.get(f)};HandValue hv=eval5(x);if(best==null||hv.compareTo(best)>0)best=hv;}return best;
    }
    private HandValue eval5(Card[] a){
        int[] cnt=new int[15];boolean flush=true;int suit=a[0].s;ArrayList<Integer> rs=new ArrayList<>();for(Card c:a){cnt[c.r]++;if(c.s!=suit)flush=false;if(!rs.contains(c.r))rs.add(c.r);}Collections.sort(rs,Collections.reverseOrder());if(rs.contains(14))rs.add(1);int straight=0,run=0,prev=-99;for(int r:rs){if(prev==r+1)run++;else run=1;if(run>=5){straight=r+4;break;}prev=r;}if(flush&&straight>0)return new HandValue(new int[]{8,straight},"Стрит-флеш · "+rankName(straight));int four=0,three=0;ArrayList<Integer> pairs=new ArrayList<>();for(int r=14;r>=2;r--){if(cnt[r]==4)four=r;else if(cnt[r]==3&&three==0)three=r;else if(cnt[r]>=2)pairs.add(r);}if(four>0){int k=0;for(int r=14;r>=2;r--)if(r!=four&&cnt[r]>0){k=r;break;}return new HandValue(new int[]{7,four,k},"Каре · "+rankName(four));}if(three>0&&!pairs.isEmpty())return new HandValue(new int[]{6,three,pairs.get(0)},"Фулл-хаус · "+rankName(three));if(flush){int[] v=new int[6];v[0]=5;for(int i=0;i<5;i++)v[i+1]=rs.get(i);return new HandValue(v,"Флеш · "+rankName(rs.get(0)));}if(straight>0)return new HandValue(new int[]{4,straight},"Стрит · до "+rankName(straight));if(three>0){ArrayList<Integer> k=new ArrayList<>();for(int r=14;r>=2;r--)if(r!=three&&cnt[r]>0)k.add(r);return new HandValue(new int[]{3,three,k.get(0),k.get(1)},"Сет · "+rankName(three));}if(pairs.size()>=2){int p1=pairs.get(0),p2=pairs.get(1),k=0;for(int r=14;r>=2;r--)if(r!=p1&&r!=p2&&cnt[r]>0){k=r;break;}return new HandValue(new int[]{2,p1,p2,k},"Две пары · "+rankName(p1)+" / "+rankName(p2));}if(pairs.size()==1){int pr=pairs.get(0);ArrayList<Integer> k=new ArrayList<>();for(int r=14;r>=2;r--)if(r!=pr&&cnt[r]>0)k.add(r);return new HandValue(new int[]{1,pr,k.get(0),k.get(1),k.get(2)},"Пара · "+rankName(pr));}int[] v=new int[6];v[0]=0;int j=1;for(int r=14;r>=2;r--)if(cnt[r]>0)v[j++]=r;return new HandValue(v,"Старшая карта · "+rankName(v[1]));
    }
    private String rankName(int r){return r==14?"A":r==13?"K":r==12?"Q":r==11?"J":String.valueOf(r);}

    // ---------- Blackjack ----------
    private void enterBJ(){screen=Screen.BLACKJACK;newBJTable();invalidate();}
    private void newBJTable(){ArrayList<OpponentDef>a=randomOpponents(4);bjDealer=a.get(0);bjOthers.clear();for(int i=1;i<a.size();i++)bjOthers.add(a.get(i));bjRound=false;bjDone=false;dealerReveal=false;bjMessage="Сделайте ставку";bjHands.clear();dealerCards.clear();bjOtherHands.clear();}
    private int bjValue(List<Card> cards){int sum=0,aces=0;for(Card c:cards){if(c.r==14){sum+=11;aces++;}else sum+=Math.min(10,c.r);}while(sum>21&&aces-->0)sum-=10;return sum;}
    private boolean bjNatural(BJHand h){return h.cards.size()==2&&bjValue(h.cards)==21&&!h.fromSplit;}
    private void dealBJ(){if(bjRound||chips<bjBet)return;chips-=bjBet;save();bjDeck=new Deck(6,rng);bjHands.clear();BJHand u=new BJHand(bjBet);bjHands.add(u);dealerCards.clear();bjOtherHands.clear();for(int i=0;i<bjOthers.size();i++)bjOtherHands.add(new ArrayList<Card>());for(int r=0;r<2;r++){u.cards.add(bjDeck.draw());for(ArrayList<Card> h:bjOtherHands)h.add(bjDeck.draw());dealerCards.add(bjDeck.draw());}bjHandIndex=0;bjRound=true;bjDone=false;dealerReveal=false;insuranceOffered=dealerCards.get(0).r==14;insuranceTaken=false;insuranceBet=0;bjMessage=insuranceOffered?"У дилера туз: доступна страховка":"Ваш ход";autoPlayBJOthers();if(bjNatural(u)&&!insuranceOffered)finishBJDealer();invalidate();}
    private void autoPlayBJOthers(){for(ArrayList<Card> h:bjOtherHands)while(bjValue(h)<16)h.add(bjDeck.draw());}
    private void bjAction(String a){if(!bjRound||bjDone)return;BJHand h=bjHands.get(bjHandIndex);if(a.equals("insurance")&&insuranceOffered&&!insuranceTaken){int cost=h.bet/2;if(chips>=cost){chips-=cost;insuranceTaken=true;insuranceBet=cost;save();bjMessage="Страховка принята";}invalidate();return;}if(a.equals("hit")){h.cards.add(bjDeck.draw());if(bjValue(h.cards)>21){h.busted=true;h.stood=true;nextBJHand();}else if(bjValue(h.cards)==21){h.stood=true;nextBJHand();}}
        else if(a.equals("stand")){h.stood=true;nextBJHand();}
        else if(a.equals("double")&&h.cards.size()==2&&chips>=h.bet){chips-=h.bet;save();h.bet*=2;h.doubled=true;h.cards.add(bjDeck.draw());if(bjValue(h.cards)>21)h.busted=true;h.stood=true;nextBJHand();}
        else if(a.equals("split")&&canSplit(h)){chips-=h.bet;save();Card moved=h.cards.remove(1);BJHand h2=new BJHand(h.bet);h2.fromSplit=true;h.fromSplit=true;h2.cards.add(moved);h.cards.add(bjDeck.draw());h2.cards.add(bjDeck.draw());bjHands.add(bjHandIndex+1,h2);}
        invalidate();}
    private boolean canSplit(BJHand h){return h.cards.size()==2&&h.cards.get(0).r==h.cards.get(1).r&&bjHands.size()<4&&chips>=h.bet;}
    private void nextBJHand(){for(int i=bjHandIndex+1;i<bjHands.size();i++)if(!bjHands.get(i).stood){bjHandIndex=i;bjMessage="Рука "+(i+1);return;}finishBJDealer();}
    private void finishBJDealer(){dealerReveal=true;int dv=bjValue(dealerCards);while(dv<16){dealerCards.add(bjDeck.draw());dv=bjValue(dealerCards);}settleBJ();}
    private void settleBJ(){int dv=bjValue(dealerCards);boolean dealerBust=dv>21;boolean dealerBJ=dealerCards.size()==2&&dv==21;int winTotal=0;for(BJHand h:bjHands){int v=bjValue(h.cards);int ret=0;if(h.busted){h.result="Проигрыш";}else if(dealerBJ&&!bjNatural(h)){h.result="Дилер: blackjack";}else if(bjNatural(h)&&!dealerBJ){ret=h.bet+(h.bet*3)/2;h.result="BLACKJACK +"+(ret-h.bet);}else if(dealerBJ&&bjNatural(h)){ret=h.bet;h.result="Push";}else if(dealerBust||v>dv){ret=h.bet*2;h.result="Победа +"+h.bet;}else if(v==dv){ret=h.bet;h.result="Push";}else h.result="Проигрыш";chips+=ret;winTotal+=Math.max(0,ret-h.bet);}if(insuranceTaken&&dealerBJ){int ret=insuranceBet*3;chips+=ret;winTotal+=ret-insuranceBet;}save();bjDone=true;bjMessage=dealerBust?"Дилер перебрал":dealerBJ?"Blackjack у дилера":"Дилер остановился на "+dv;if(winTotal>0)celebrate();invalidate();}

    private void drawBlackjack(Canvas c){topBar(c);RectF t=tableRect();drawTable(c,t);boolean land=getWidth()>getHeight();RectF back=new RectF(dp(12),dp(72),dp(56),dp(112));round(c,back,10,Color.argb(180,4,30,22));txt(c,"‹",back.centerX(),back.centerY()+dp(8),26,WHITE,Paint.Align.CENTER,true);hits.add(new Hit(back,"back"));
        float dealerY=t.top+(land?t.height()*.16f:t.height()*.13f);RectF da=new RectF(t.centerX()-dp(42),dealerY-dp(42),t.centerX()+dp(42),dealerY+dp(42));drawAvatar(c,bjDealer.res,da,12);outline(c,da,12,GOLD,2);txt(c,"ДИЛЕР · "+bjDealer.name,t.centerX(),da.bottom+dp(25),12,WHITE,Paint.Align.CENTER,true);if(bjRound){float cx=t.centerX()-(dealerCards.size()-1)*dp(21);for(int i=0;i<dealerCards.size();i++){if(i==1&&!dealerReveal)drawCardBack(c,cx+i*dp(42),da.bottom+dp(92),false);else drawFullCard(c,dealerCards.get(i),cx+i*dp(42),da.bottom+dp(62),.82f);}if(dealerReveal)txt(c,""+bjValue(dealerCards),t.centerX()+dp(115),da.bottom+dp(70),12,GOLD_LIGHT,Paint.Align.LEFT,true);}
        drawBJOthers(c,t,land);drawBJUser(c,t,land);drawBJControls(c,t,land);
    }
    private void drawBJOthers(Canvas c,RectF t,boolean land){if(bjOthers.isEmpty())return;float y=t.top+t.height()*(land?.44f:.47f);for(int i=0;i<bjOthers.size();i++){float x=t.left+t.width()*(.27f+i*(.46f/Math.max(1,bjOthers.size()-1)));OpponentDef d=bjOthers.get(i);RectF a=new RectF(x-dp(32),y-dp(32),x+dp(32),y+dp(32));drawAvatar(c,d.res,a,10);outline(c,a,10,GOLD,1.5f);txt(c,d.name,x,y+dp(52),9,WHITE,Paint.Align.CENTER,true);if(bjRound&&i<bjOtherHands.size()){ArrayList<Card> h=bjOtherHands.get(i);txt(c,""+bjValue(h),x,y+dp(70),8,GOLD_LIGHT,Paint.Align.CENTER,true);}}
    }
    private void drawBJUser(Canvas c,RectF t,boolean land){float y=t.bottom-(land?dp(118):dp(190));if(!bjRound){txt(c,"Ставка",t.centerX()-dp(120),y,12,MUTED,Paint.Align.LEFT,false);RectF minus=new RectF(t.centerX()-dp(55),y-dp(35),t.centerX()-dp(10),y+dp(10));button(c,minus,"−","bjBetMinus",false);txt(c,"◎ "+bjBet,t.centerX()+dp(25),y,17,WHITE,Paint.Align.CENTER,true);RectF plus=new RectF(t.centerX()+dp(65),y-dp(35),t.centerX()+dp(110),y+dp(10));button(c,plus,"+","bjBetPlus",false);RectF deal=new RectF(t.centerX()-dp(85),y+dp(25),t.centerX()+dp(85),y+dp(78));button(c,deal,"РАЗДАТЬ","bjDeal",true);RectF nr=new RectF(t.centerX()-dp(85),y+dp(88),t.centerX()+dp(85),y+dp(136));button(c,nr,"НОВЫЙ СОСТАВ","bjRoster",false);return;}
        BJHand h=bjHands.get(Math.min(bjHandIndex,bjHands.size()-1));float cx=t.centerX()-(h.cards.size()-1)*dp(22);for(int i=0;i<h.cards.size();i++)drawFullCard(c,h.cards.get(i),cx+i*dp(44),y,.92f);txt(c,"ВЫ · "+bjValue(h.cards)+" · ставка "+h.bet,t.centerX(),y+dp(62),11,WHITE,Paint.Align.CENTER,true);if(!h.result.isEmpty())txt(c,h.result,t.centerX(),y+dp(82),10,GOLD_LIGHT,Paint.Align.CENTER,true);if(bjHands.size()>1)txt(c,"Рука "+(bjHandIndex+1)+" / "+bjHands.size(),t.centerX(),y-dp(48),8,MUTED,Paint.Align.CENTER,true);
    }
    private void drawBJControls(Canvas c,RectF t,boolean land){float y=t.bottom-dp(66);RectF msg=new RectF(t.left+t.width()*.09f,t.top+t.height()*.19f,t.left+t.width()*.09f+Math.min(dp(200),t.width()*.34f),t.top+t.height()*.19f+dp(38));round(c,msg,10,Color.argb(220,3,25,18));txt(c,bjMessage,msg.left+dp(10),msg.centerY()+dp(4),9,WHITE,Paint.Align.LEFT,true);if(!bjRound)return;if(bjDone){RectF n=new RectF(t.centerX()-dp(85),y,t.centerX()+dp(85),y+dp(52));button(c,n,"НОВАЯ ИГРА","bjReset",true);return;}BJHand h=bjHands.get(bjHandIndex);float w=Math.min(t.width()*.78f,dp(680)),gap=dp(5),bw=(w-gap*6)/5,x=t.centerX()-w/2;RectF b=new RectF(x,y,x+bw,y+dp(50));button(c,b,"HIT","bjHit",false);b.offset(bw+gap,0);button(c,b,"STAND","bjStand",false);b.offset(bw+gap,0);button(c,b,"DOUBLE","bjDouble",chips>=h.bet&&h.cards.size()==2);b.offset(bw+gap,0);button(c,b,"SPLIT","bjSplit",canSplit(h));b.offset(bw+gap,0);button(c,b,insuranceOffered&&!insuranceTaken?"INSURE":"—","bjInsurance",insuranceOffered&&!insuranceTaken);}

    // ---------- Effects / audio ----------
    private void celebrate(){long now=System.currentTimeMillis();int[] colors={GOLD,Color.WHITE,Color.rgb(239,80,70),Color.rgb(92,185,255),Color.rgb(108,226,139)};for(int i=0;i<110;i++){Confetti q=new Confetti();q.x=rng.nextFloat()*getWidth();q.y=-rng.nextFloat()*getHeight()*.3f;q.vx=(rng.nextFloat()-.5f)*dp(2.7f);q.vy=dp(2.3f+rng.nextFloat()*4);q.rot=rng.nextFloat()*360;q.vr=(rng.nextFloat()-.5f)*12;q.color=colors[rng.nextInt(colors.length)];q.born=now+rng.nextInt(450);q.life=2200+rng.nextInt(1200);confetti.add(q);}for(int i=0;i<6;i++){Firework f=new Firework();f.x=getWidth()*(.15f+rng.nextFloat()*.7f);f.y=getHeight()*(.18f+rng.nextFloat()*.48f);f.max=dp(45+rng.nextInt(55));f.color=colors[rng.nextInt(colors.length)];f.born=now+180+i*210;f.life=800;fireworks.add(f);}if(soundOn)playWinMelody();invalidate();}
    private void playWinMelody(){final int[] notes={ToneGenerator.TONE_DTMF_1,ToneGenerator.TONE_DTMF_3,ToneGenerator.TONE_DTMF_6,ToneGenerator.TONE_DTMF_9,ToneGenerator.TONE_PROP_ACK};for(int i=0;i<notes.length;i++){final int n=notes[i];handler.postDelayed(new Runnable(){public void run(){if(soundOn)tone.startTone(n,150);}},i*155L);}}
    private void drawEffects(Canvas c){long now=System.currentTimeMillis();boolean alive=false;Iterator<ChipFly> ci=chipFlys.iterator();while(ci.hasNext()){ChipFly f=ci.next();float u=(now-f.born)/(float)f.life;if(u<0){alive=true;continue;}if(u>=1){ci.remove();continue;}alive=true;float e=1-(1-u)*(1-u);float x=f.x0+(f.x1-f.x0)*e,y=f.y0+(f.y1-f.y0)*e;for(int k=0;k<3;k++){p.setColor(k==0?Color.rgb(170,39,34):k==1?GOLD:Color.rgb(35,88,175));c.drawCircle(x+k*dp(2),y-k*dp(3),dp(7),p);}}
        Iterator<Confetti> it=confetti.iterator();while(it.hasNext()){Confetti q=it.next();float u=(now-q.born)/(float)q.life;if(u<0){alive=true;continue;}if(u>=1){it.remove();continue;}alive=true;float x=q.x+q.vx*u*120,y=q.y+q.vy*u*105+dp(120)*u*u;c.save();c.rotate(q.rot+q.vr*u*30,x,y);p.setColor(q.color);c.drawRect(x-dp(3),y-dp(6),x+dp(3),y+dp(6),p);c.restore();}
        Iterator<Firework> fi=fireworks.iterator();while(fi.hasNext()){Firework f=fi.next();float u=(now-f.born)/(float)f.life;if(u<0){alive=true;continue;}if(u>=1){fi.remove();continue;}alive=true;p.setColor(f.color);p.setStrokeWidth(dp(2));for(int k=0;k<18;k++){double a=k*Math.PI*2/18;float r=f.max*Math.min(1,u*1.4f);float x1=f.x+(float)Math.cos(a)*r*.35f,y1=f.y+(float)Math.sin(a)*r*.35f,x2=f.x+(float)Math.cos(a)*r,y2=f.y+(float)Math.sin(a)*r;c.drawLine(x1,y1,x2,y2,p);}}
        if(alive)postInvalidateOnAnimation();}

    @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX(),y=e.getY();for(int i=hits.size()-1;i>=0;i--){Hit h=hits.get(i);if(h.r.contains(x,y)){handle(h.a);break;}}return true;}
    private void handle(String a){
        if(a.equals("sound")){soundOn=!soundOn;save();invalidate();return;}if(a.equals("back")){screen=Screen.MENU;invalidate();return;}
        if(a.equals("menuPoker")){screen=Screen.POKER;newPokerRoster();invalidate();return;}if(a.equals("menuBJ")){enterBJ();return;}
        if(a.equals("fold")||a.equals("checkcall")||a.equals("raise")||a.equals("allin")){pokerAction(a);return;}if(a.equals("raiseMinus")){raiseTarget=Math.max(currentBet+minRaise,raiseTarget-20);invalidate();return;}if(a.equals("raisePlus")){Player u=pp.get(0);raiseTarget=Math.min(u.streetBet+u.stack,raiseTarget+20);invalidate();return;}if(a.equals("newPokerHand")){startPokerHand();return;}
        if(a.equals("bjBetMinus")){bjBet=Math.max(20,bjBet-20);invalidate();return;}if(a.equals("bjBetPlus")){bjBet=Math.min(Math.max(20,chips),bjBet+20);invalidate();return;}if(a.equals("bjDeal")){dealBJ();return;}if(a.equals("bjRoster")){newBJTable();invalidate();return;}if(a.equals("bjHit")){bjAction("hit");return;}if(a.equals("bjStand")){bjAction("stand");return;}if(a.equals("bjDouble")){bjAction("double");return;}if(a.equals("bjSplit")){bjAction("split");return;}if(a.equals("bjInsurance")){bjAction("insurance");return;}if(a.equals("bjReset")){bjRound=false;bjDone=false;dealerReveal=false;bjMessage="Сделайте ставку";bjHands.clear();invalidate();}
    }
}
